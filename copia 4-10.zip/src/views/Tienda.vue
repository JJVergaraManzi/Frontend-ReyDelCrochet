<template>
    <v-container >
        <TiendaComponentes/>
    </v-container>
    
</template>

<script>
import TiendaComponentes from '../components/TiendaComponentes.vue'

export default{
    components: {
        TiendaComponentes
  }
}
</script>
