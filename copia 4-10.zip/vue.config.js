module.exports = {
  transpileDependencies: [
    'vuetify'
  ]
}