<template>
  <v-card-text>
    <h1>El Rey Del Crochet</h1>
    <h4>Accesorios</h4>
  </v-card-text>
</template>
<script>
</script>
<style>

</style>
