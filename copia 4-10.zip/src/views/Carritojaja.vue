<template>
    <v-container >
        <TotalComponentes/>
    </v-container>
    
</template>

<script>
import TotalComponentes from '../components/TotalComponentes.vue'

export default{
    components: {
        TotalComponentes
  }
}
</script>
<style>
</style>