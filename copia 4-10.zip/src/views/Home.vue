<template>
      <v-parallax 
        height="900" 
        dark
        src="../assets/lanafondo3.jpg">
        <v-row
          align="center"
          justify="center">
          <v-col
            class="text-center"
            cols="12">
            <h1 class="text-h4 font-weight-thin mb-4 ">
              El Rey Del Crochet
            </h1>
            <h4 class="subheading">
              Encuentra los mejores productos!
            </h4>
          </v-col>
        </v-row>
      </v-parallax>
</template>
<script>
</script>
<style>
</style>
